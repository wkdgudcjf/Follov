package com.follov.locationupdates;

public class ActivityRecognitionIntentService {

}
