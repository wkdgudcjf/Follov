/** Automatically generated file. DO NOT MODIFY */
package com.google.maps.android.utils.demo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}